package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ScheduleService {
    private Connection connection;

    public ScheduleService(Connection connection) {
        this.connection = connection;
    }

    public void assignShift(int employeeId, String shift) {
        String sql = "INSERT INTO schedule (employee_id, shift) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            statement.setString(2, shift);
            statement.executeUpdate();
            System.out.println("Shift assigned successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to assign shift.");
            e.printStackTrace();
        }
    }

    public String getShiftByEmployeeId(int employeeId) {
        String sql = "SELECT shift FROM schedule WHERE employee_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("shift");
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to retrieve shift for employee ID " + employeeId);
            e.printStackTrace();
        }
        return null;
    }
}
