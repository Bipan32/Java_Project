package org.example;

import org.example.models.Employee;
import org.example.models.LeaveRequest;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {
    private EmployeeService employeeService;
    private ScheduleService scheduleService;
    private LeaveRequestService leaveRequestService;

    public ConsoleUI(EmployeeService employeeService, ScheduleService scheduleService, LeaveRequestService leaveRequestService) {
        this.employeeService = employeeService;
        this.scheduleService = scheduleService;
        this.leaveRequestService = leaveRequestService;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("-------------------------");
            System.out.println("1. Add Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. View Employee Details");
            System.out.println("4. Assign Shift");
            System.out.println("5. Submit Leave Request");
            System.out.println("6. Edit/Delete Employee Information");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            System.out.println("-------------------------");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addEmployee(scanner);
                    break;
                case 2:
                    viewAllEmployees();
                    break;
                case 3:
                    viewEmployeeDetails(scanner);
                    break;
                case 4:
                    assignShift(scanner);
                    break;
                case 5:
                    submitLeaveRequest(scanner);
                    break;
                case 6:
                    editOrDeleteEmployee(scanner);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
        scanner.close();
    }

    private void addEmployee(Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter employee name: ");
        String name = scanner.nextLine();
        System.out.print("Enter employee position: ");
        String position = scanner.nextLine();
        System.out.print("Enter employee department: ");
        String department = scanner.nextLine();
        System.out.println("-------------------------");

        Employee employee = new Employee(0, name, position, department);
        employeeService.addEmployee(employee);
    }

    private void viewAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            System.out.println("Employees:");
            for (Employee employee : employees) {
                System.out.println(employee.getId() + ". " + employee.getName() + " - " + employee.getPosition() + " in " + employee.getDepartment());
            }
        }
    }

    private void viewEmployeeDetails(Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Employee employee = employeeService.getEmployeeById(employeeId);
        if (employee != null) {
            System.out.println("Employee Details:");
            System.out.println("Name: " + employee.getName());
            System.out.println("Position: " + employee.getPosition());
            System.out.println("Department: " + employee.getDepartment());

            // Check if the employee has pending leave requests
            List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsByEmployeeId(employeeId);
            if (!leaveRequests.isEmpty()) {
                System.out.println("Leave Requests:");
                for (LeaveRequest leaveRequest : leaveRequests) {
                    System.out.println("Start Date: " + leaveRequest.getStartDate());
                    System.out.println("End Date: " + leaveRequest.getEndDate());
                    System.out.println("Reason: " + leaveRequest.getReason());
                    System.out.println("Status: " + leaveRequest.getStatus());
                }
            } else {
                System.out.println("No pending leave requests for this employee.");
            }

            // Check the assigned shift for the employee
            String shift = scheduleService.getShiftByEmployeeId(employeeId);
            if (shift != null) {
                System.out.println("Assigned Shift: " + shift);
            } else {
                System.out.println("No assigned shift for this employee.");
            }
        } else {
            System.out.println("Employee not found.");
        }
        System.out.println("-------------------------");
    }

    private void assignShift(Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter shift: ");
        String shift = scanner.nextLine();
        System.out.println("-------------------------");

        scheduleService.assignShift(employeeId, shift);
    }

    private void submitLeaveRequest(Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter start date (yyyy-MM-dd): ");
        String startDateStr = scanner.nextLine();
        System.out.print("Enter end date (yyyy-MM-dd): ");
        String endDateStr = scanner.nextLine();
        System.out.print("Enter reason: ");
        String reason = scanner.nextLine();
        System.out.println("-------------------------");

        Date startDate = java.sql.Date.valueOf(startDateStr);
        Date endDate = java.sql.Date.valueOf(endDateStr);

        LeaveRequest leaveRequest = new LeaveRequest(employeeId, startDate, endDate, reason, "Pending");
        leaveRequestService.submitLeaveRequest(leaveRequest);
    }

    private void editOrDeleteEmployee(Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("-------------------------");
        System.out.println("1. Edit Employee");
        System.out.println("2. Delete Employee");
        System.out.println("-------------------------");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        switch (choice) {
            case 1:
                editEmployee(employeeId, scanner);
                break;
            case 2:
                deleteEmployee(employeeId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void editEmployee(int employeeId, Scanner scanner) {
        System.out.println("-------------------------");
        System.out.print("Enter new employee name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new employee position: ");
        String position = scanner.nextLine();
        System.out.print("Enter new employee department: ");
        String department = scanner.nextLine();
        System.out.println("-------------------------");

        Employee updatedEmployee = new Employee(employeeId, name, position, department);
        employeeService.updateEmployee(updatedEmployee);
        System.out.println("Employee information updated successfully.");
    }

    private void deleteEmployee(int employeeId) {
        employeeService.deleteEmployee(employeeId);
        System.out.println("Employee deleted successfully.");
    }
}
