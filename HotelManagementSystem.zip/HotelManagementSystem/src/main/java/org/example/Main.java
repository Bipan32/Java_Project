package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        // Establish database connection
        try (Connection connection = DatabaseConnector.connect()) {
            System.out.println("Connected to the database.");

            // Create tables if they don't exist
            DatabaseConnector.createTables(connection);

            // Initialize service classes
            EmployeeService employeeService = new EmployeeService(connection);
            ScheduleService scheduleService = new ScheduleService(connection);
            LeaveRequestService leaveRequestService = new LeaveRequestService(connection);

            // Initialize UI
            ConsoleUI consoleUI = new ConsoleUI(employeeService, scheduleService, leaveRequestService);
            consoleUI.start();
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }
    }
}
