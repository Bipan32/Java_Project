package org.example;

import org.example.models.LeaveRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LeaveRequestService {
    private Connection connection;

    public LeaveRequestService(Connection connection) {
        this.connection = connection;
    }

    public void submitLeaveRequest(LeaveRequest leaveRequest) {
        String sql = "INSERT INTO leave_requests (employee_id, start_date, end_date, reason, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, leaveRequest.getEmployeeId());
            statement.setDate(2, new java.sql.Date(leaveRequest.getStartDate().getTime()));
            statement.setDate(3, new java.sql.Date(leaveRequest.getEndDate().getTime()));
            statement.setString(4, leaveRequest.getReason());
            statement.setString(5, leaveRequest.getStatus());
            statement.executeUpdate();
            System.out.println("Leave request submitted successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to submit leave request.");
            e.printStackTrace();
        }
    }

    public List<LeaveRequest> getLeaveRequestsByEmployeeId(int employeeId) {
        List<LeaveRequest> leaveRequests = new ArrayList<>();
        String sql = "SELECT * FROM leave_requests WHERE employee_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    Date startDate = resultSet.getDate("start_date");
                    Date endDate = resultSet.getDate("end_date");
                    String reason = resultSet.getString("reason");
                    String status = resultSet.getString("status");
                    leaveRequests.add(new LeaveRequest(employeeId, startDate, endDate, reason, status));
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to retrieve leave requests for employee ID " + employeeId);
            e.printStackTrace();
        }
        return leaveRequests;
    }

    public void updateLeaveRequestStatus(int leaveRequestId, String newStatus) {
        String sql = "UPDATE leave_requests SET status = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newStatus);
            statement.setInt(2, leaveRequestId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Leave request status updated successfully.");
            } else {
                System.out.println("No leave request found with ID " + leaveRequestId);
            }
        } catch (SQLException e) {
            System.out.println("Failed to update leave request status.");
            e.printStackTrace();
        }
    }
}
