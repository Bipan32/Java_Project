// Schedule.java
package org.example.models;

import java.util.Date;

public class Schedule {
    private int employeeId;
    private Date date;
    private String shift;

    public Schedule(int employeeId, Date date, String shift) {
        this.employeeId = employeeId;
        this.date = date;
        this.shift = shift;
    }

    // Getters and setters
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }
}
