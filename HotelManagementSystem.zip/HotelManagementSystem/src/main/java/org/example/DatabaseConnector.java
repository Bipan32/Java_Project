package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnector {
    // SQLite database URL
    private static final String DB_URL = "jdbc:sqlite:hoteldb.db";

    // Establish connection to the database
    public static Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(DB_URL);
            System.out.println("Connected to the database.");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }
        return conn;
    }

    // Close the connection to the database
    public static void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Connection to the database closed.");
            } catch (SQLException e) {
                System.out.println("Failed to close connection to the database.");
                e.printStackTrace();
            }
        }
    }

    // Create tables if they don't exist
    public static void createTables(Connection conn) {
        if (conn != null) {
            try (Statement statement = conn.createStatement()) {
                // Create employees table
                statement.execute("CREATE TABLE IF NOT EXISTS employees (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT," +
                        "position TEXT," +
                        "department TEXT)");

                // Create schedule table
                statement.execute("CREATE TABLE IF NOT EXISTS schedule (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "employee_id INTEGER," +
                        "date DATE," +
                        "shift TEXT)");

                // Create leave_requests table
                statement.execute("CREATE TABLE IF NOT EXISTS leave_requests (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "employee_id INTEGER," +
                        "start_date DATE," +
                        "end_date DATE," +
                        "reason TEXT," +
                        "status TEXT)");

                System.out.println("Tables created successfully.");
            } catch (SQLException e) {
                System.out.println("Failed to create tables.");
                e.printStackTrace();
            }
        }
    }
}
